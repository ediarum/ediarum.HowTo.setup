/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {7:3,12:10,18:17,17:14,28:25,9:10,11:10,25:14,15:17,19:17,10:3,14:-1,31:14,24:25,32:14,3:-1,35:14,21:17,26:25,4:3};
});