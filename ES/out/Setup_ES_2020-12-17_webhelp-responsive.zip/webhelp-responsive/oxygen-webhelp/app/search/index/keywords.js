define(function() {var keywords=[{w:"Editionsspezifische",p:["p0"]},{w:"Konfiguration",p:["p0"]},{w:"Ein",p:["p1"]},{w:"eigenes",p:["p1"]},{w:"Register",p:["p1"]},{w:"anlegen",p:["p1","p7","p8","p12"]},{w:"\u00DCber",p:["p2","p14","p15"]},{w:"Oxygen-Frameworks",p:["p2"]},{w:"und",p:["p2","p13"]},{w:"ediarum-Spezifika",p:["p2"]},{w:"Basis-Setup",p:["p3","p14"]},{w:"Activar",p:["p4"]},{w:"los",p:["p4"]},{w:"registros",p:["p4"]},{w:"de",p:["p4","p10"]},{w:"ediarum",p:["p4","p10"]},{w:"/",p:["p4"]},{w:"\u201CEdiarum-Register\u201D",p:["p4"]},{w:"ediarum.DB",p:["p5"]},{w:"App",p:["p5"]},{w:"installieren",p:["p5"]},{w:"Datenbank",p:["p6","p7","p11"]},{w:"einrichten",p:["p6","p9"]},{w:"Projekt",p:["p7","p12"]},{w:"in",p:["p7","p9"]},{w:"der",p:["p7","p11"]},{w:"Nutzer-Account",p:["p8"]},{w:"Arbeitsumgebung",p:["p9"]},{w:"Oxygen",p:["p9","p11","p12","p13"]},{w:"XML",p:["p9","p12"]},{w:"Author",p:["p9","p12"]},{w:"Instalar",p:["p10"]},{w:"el",p:["p10"]},{w:"framework",p:["p10"]},{w:"mit",p:["p11"]},{w:"verbinden",p:["p11"]},{w:"im",p:["p12"]},{w:"Installationstipps",p:["p13"]},{w:"eXist-db",p:["p13"]},{w:"\u00DCberblick",p:["p14"]},{w:"das",p:["p14"]},{w:"diese",p:["p15"]},{w:"Anleitung",p:["p15"]}];
var ph={};
ph["p0"]=[0, 1];
ph["p1"]=[2, 3, 4, 5];
ph["p2"]=[6, 7, 8, 9];
ph["p3"]=[10];
ph["p4"]=[11, 12, 13, 14, 15, 16, 17];
ph["p5"]=[18, 19, 20];
ph["p6"]=[21, 22];
ph["p7"]=[23, 24, 25, 21, 5];
ph["p8"]=[26, 5];
ph["p9"]=[27, 24, 28, 29, 30, 22];
ph["p10"]=[31, 32, 33, 14, 15];
ph["p12"]=[23, 36, 28, 29, 30, 5];
ph["p11"]=[28, 34, 25, 21, 35];
ph["p14"]=[39, 6, 40, 10];
ph["p13"]=[37, 38, 8, 28];
ph["p15"]=[6, 41, 42];
     return {
         keywords: keywords,
         ph: ph
     }
});
