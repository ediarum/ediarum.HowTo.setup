/**
 * Load the libraries for the Index Terms page.
 */
define(["require", "config"], function() {
    require([
        'nav-links-loader',
        'expand',
        'template-module-loader'
    ]);
});