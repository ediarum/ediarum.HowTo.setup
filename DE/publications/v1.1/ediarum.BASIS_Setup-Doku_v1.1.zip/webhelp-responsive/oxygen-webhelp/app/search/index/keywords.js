define(function() {var keywords=[{w:"ediarum-Architektur",p:["p0"]},{w:"mit",p:["p0","p12"]},{w:"dem",p:["p0"]},{w:"Basis-Setup",p:["p0","p3"]},{w:"\u00DCberblick",p:["p1"]},{w:"\u00FCber",p:["p1","p10"]},{w:"das",p:["p1"]},{w:"Setup",p:["p1"]},{w:"Editionsspezifische",p:["p2"]},{w:"Konfiguration",p:["p2"]},{w:"Datenbank",p:["p4","p9","p12"]},{w:"einrichten",p:["p4","p8","p11","p14"]},{w:"Nutzer-Account",p:["p5"]},{w:"anlegen",p:["p5","p9","p13"]},{w:"ediarum-Register",p:["p6"]},{w:"aktivieren",p:["p6"]},{w:"ediarum.DB",p:["p7"]},{w:"App",p:["p7"]},{w:"installieren",p:["p7"]},{w:"Ein",p:["p8"]},{w:"eigenes",p:["p8"]},{w:"Register",p:["p8"]},{w:"Projekt",p:["p9","p13"]},{w:"in",p:["p9","p11"]},{w:"der",p:["p9","p12"]},{w:"Oxygen-Frameworks",p:["p10"]},{w:"und",p:["p10"]},{w:"ediarum-Spezifika",p:["p10"]},{w:"Arbeitsumgebung",p:["p11"]},{w:"Oxygen",p:["p11","p12","p13"]},{w:"XML",p:["p11","p13"]},{w:"Author",p:["p11","p13"]},{w:"verbinden",p:["p12"]},{w:"im",p:["p13"]},{w:"ediarum-Frameworks",p:["p14"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3];
ph["p1"]=[4, 5, 6, 7];
ph["p2"]=[8, 9];
ph["p3"]=[3];
ph["p4"]=[10, 11];
ph["p5"]=[12, 13];
ph["p6"]=[14, 15];
ph["p7"]=[16, 17, 18];
ph["p8"]=[19, 20, 21, 11];
ph["p9"]=[22, 23, 24, 10, 13];
ph["p10"]=[5, 25, 26, 27];
ph["p12"]=[29, 1, 24, 10, 32];
ph["p11"]=[28, 23, 29, 30, 31, 11];
ph["p14"]=[34, 11];
ph["p13"]=[22, 33, 29, 30, 31, 13];
     return {
         keywords: keywords,
         ph: ph
     }
});
