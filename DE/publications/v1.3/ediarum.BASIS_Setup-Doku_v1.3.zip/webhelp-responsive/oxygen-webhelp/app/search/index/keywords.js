define(function() {var keywords=[{w:"\u00DCberblick",p:["p0"]},{w:"\u00FCber",p:["p0","p1","p12"]},{w:"das",p:["p0"]},{w:"Basis-Setup",p:["p0","p3"]},{w:"diese",p:["p1"]},{w:"Anleitung",p:["p1"]},{w:"Editionsspezifische",p:["p2"]},{w:"Konfiguration",p:["p2"]},{w:"Installationstipps",p:["p4"]},{w:"eXist-db",p:["p4","p5"]},{w:"und",p:["p4","p5","p12"]},{w:"Oxygen",p:["p4","p5","p13","p14","p15"]},{w:"installieren",p:["p5","p10"]},{w:"Datenbank",p:["p6","p8","p14"]},{w:"einrichten",p:["p6","p11","p13","p16"]},{w:"Nutzer-Account",p:["p7"]},{w:"anlegen",p:["p7","p8","p15"]},{w:"Projekt",p:["p8","p15"]},{w:"in",p:["p8","p13"]},{w:"der",p:["p8","p14"]},{w:"ediarum-Register",p:["p9"]},{w:"aktivieren",p:["p9"]},{w:"ediarum.DB",p:["p10"]},{w:"App",p:["p10"]},{w:"Ein",p:["p11"]},{w:"eigenes",p:["p11"]},{w:"Register",p:["p11"]},{w:"Oxygen-Frameworks",p:["p12"]},{w:"ediarum-Spezifika",p:["p12"]},{w:"Arbeitsumgebung",p:["p13"]},{w:"XML",p:["p13","p15"]},{w:"Author",p:["p13","p15"]},{w:"mit",p:["p14"]},{w:"verbinden",p:["p14"]},{w:"im",p:["p15"]},{w:"ediarum-Frameworks",p:["p16"]}];
var ph={};
ph["p0"]=[0, 1, 2, 3];
ph["p1"]=[1, 4, 5];
ph["p2"]=[6, 7];
ph["p3"]=[3];
ph["p4"]=[8, 9, 10, 11];
ph["p5"]=[9, 10, 11, 12];
ph["p6"]=[13, 14];
ph["p7"]=[15, 16];
ph["p8"]=[17, 18, 19, 13, 16];
ph["p9"]=[20, 21];
ph["p10"]=[22, 23, 12];
ph["p12"]=[1, 27, 10, 28];
ph["p11"]=[24, 25, 26, 14];
ph["p14"]=[11, 32, 19, 13, 33];
ph["p13"]=[29, 18, 11, 30, 31, 14];
ph["p16"]=[35, 14];
ph["p15"]=[17, 34, 11, 30, 31, 16];
     return {
         keywords: keywords,
         ph: ph
     }
});
