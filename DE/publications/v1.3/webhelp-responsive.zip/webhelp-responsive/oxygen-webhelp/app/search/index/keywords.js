define(function() {var keywords=[{w:"Basis-Setup",p:["p0","p11"]},{w:"ediarum.DB",p:["p1"]},{w:"App",p:["p1"]},{w:"installieren",p:["p1"]},{w:"Datenbank",p:["p2","p3","p8"]},{w:"einrichten",p:["p2","p6","p7","p19"]},{w:"Projekt",p:["p3","p9"]},{w:"in",p:["p3","p6","p17"]},{w:"der",p:["p3","p8","p18"]},{w:"anlegen",p:["p3","p5","p9","p12","p14"]},{w:"ediarum-Register",p:["p4"]},{w:"aktivieren",p:["p4"]},{w:"Nutzer-Account",p:["p5"]},{w:"Arbeitsumgebung",p:["p6"]},{w:"Oxygen",p:["p6","p8","p9","p10","p17"]},{w:"XML",p:["p6","p9"]},{w:"Author",p:["p6","p9"]},{w:"ediarum-Frameworks",p:["p7"]},{w:"mit",p:["p8"]},{w:"verbinden",p:["p8"]},{w:"im",p:["p9"]},{w:"Installationstipps",p:["p10"]},{w:"eXist-db",p:["p10"]},{w:"und",p:["p10","p15"]},{w:"\u00DCberblick",p:["p11"]},{w:"\u00FCber",p:["p11","p15","p20"]},{w:"das",p:["p11","p17"]},{w:"Eigene",p:["p12"]},{w:"Aktionen",p:["p12"]},{w:"Editionsspezifische",p:["p13"]},{w:"Konfiguration",p:["p13"]},{w:"Ein",p:["p14","p18"]},{w:"eigenes",p:["p14"]},{w:"Register",p:["p14","p16","p18"]},{w:"Oxygen-Frameworks",p:["p15"]},{w:"ediarum-Spezifika",p:["p15"]},{w:"Literaturbest\u00E4nde",p:["p16"]},{w:"aus",p:["p16"]},{w:"Zotero",p:["p16","p19"]},{w:"als",p:["p16"]},{w:"einbinden",p:["p16","p17"]},{w:"Zotero-Register",p:["p17"]},{w:"Zotero-Eintr\u00E4ge",p:["p18"]},{w:"erstellen",p:["p18"]},{w:"Eine",p:["p19"]},{w:"Verbindung",p:["p19"]},{w:"zu",p:["p19"]},{w:"diese",p:["p20"]},{w:"Anleitung",p:["p20"]}];
var ph={};
ph["p0"]=[0];
ph["p1"]=[1, 2, 3];
ph["p2"]=[4, 5];
ph["p3"]=[6, 7, 8, 4, 9];
ph["p4"]=[10, 11];
ph["p5"]=[12, 9];
ph["p6"]=[13, 7, 14, 15, 16, 5];
ph["p7"]=[17, 5];
ph["p8"]=[14, 18, 8, 4, 19];
ph["p9"]=[6, 20, 14, 15, 16, 9];
ph["p10"]=[21, 22, 23, 14];
ph["p20"]=[25, 47, 48];
ph["p12"]=[27, 28, 9];
ph["p11"]=[24, 25, 26, 0];
ph["p14"]=[31, 32, 33, 9];
ph["p13"]=[29, 30];
ph["p16"]=[36, 37, 38, 39, 33, 40];
ph["p15"]=[25, 34, 23, 35];
ph["p18"]=[31, 33, 8, 42, 43];
ph["p17"]=[26, 41, 7, 14, 40];
ph["p19"]=[44, 45, 46, 38, 5];
     return {
         keywords: keywords,
         ph: ph
     }
});
