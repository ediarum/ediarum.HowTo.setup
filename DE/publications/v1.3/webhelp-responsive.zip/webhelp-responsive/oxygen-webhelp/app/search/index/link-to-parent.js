/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {33:23,19:16,30:29,32:29,12:13,29:23,28:25,23:-1,14:13,31:29,25:23,13:-1,35:23,24:25,27:25,18:16,17:16,16:13,15:13,34:23,26:25};
});