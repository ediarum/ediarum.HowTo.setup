define(function() {var keywords=[{w:"Basis-Setup",p:["p0","p11"]},{w:"ediarum.DB",p:["p1"]},{w:"App",p:["p1"]},{w:"installieren",p:["p1"]},{w:"Datenbank",p:["p2","p3","p8"]},{w:"einrichten",p:["p2","p6","p7"]},{w:"Projekt",p:["p3","p9"]},{w:"in",p:["p3","p6"]},{w:"der",p:["p3","p8"]},{w:"anlegen",p:["p3","p5","p9","p13"]},{w:"ediarum-Register",p:["p4"]},{w:"aktivieren",p:["p4"]},{w:"Nutzer-Account",p:["p5"]},{w:"Arbeitsumgebung",p:["p6"]},{w:"Oxygen",p:["p6","p8","p9","p10"]},{w:"XML",p:["p6","p9"]},{w:"Author",p:["p6","p9"]},{w:"ediarum-Frameworks",p:["p7"]},{w:"mit",p:["p8"]},{w:"verbinden",p:["p8"]},{w:"im",p:["p9"]},{w:"Installationstipps",p:["p10"]},{w:"eXist-db",p:["p10"]},{w:"und",p:["p10","p14"]},{w:"\u00DCberblick",p:["p11"]},{w:"\u00FCber",p:["p11","p14","p15"]},{w:"das",p:["p11"]},{w:"Editionsspezifische",p:["p12"]},{w:"Konfiguration",p:["p12"]},{w:"Ein",p:["p13"]},{w:"eigenes",p:["p13"]},{w:"Register",p:["p13"]},{w:"Oxygen-Frameworks",p:["p14"]},{w:"ediarum-Spezifika",p:["p14"]},{w:"diese",p:["p15"]},{w:"Anleitung",p:["p15"]}];
var ph={};
ph["p0"]=[0];
ph["p1"]=[1, 2, 3];
ph["p2"]=[4, 5];
ph["p3"]=[6, 7, 8, 4, 9];
ph["p4"]=[10, 11];
ph["p5"]=[12, 9];
ph["p6"]=[13, 7, 14, 15, 16, 5];
ph["p7"]=[17, 5];
ph["p8"]=[14, 18, 8, 4, 19];
ph["p9"]=[6, 20, 14, 15, 16, 9];
ph["p10"]=[21, 22, 23, 14];
ph["p12"]=[27, 28];
ph["p11"]=[24, 25, 26, 0];
ph["p14"]=[25, 32, 23, 33];
ph["p13"]=[29, 30, 31, 9];
ph["p15"]=[25, 34, 35];
     return {
         keywords: keywords,
         ph: ph
     }
});
